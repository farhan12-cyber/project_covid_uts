<?php

// Nama : Muhammad Farhan
// Kelas : 3TI05
// Nim : 0110220079

use App\Http\Controllers\PatientsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

# Method (GET) All Resource
Route::get("/patients", [PatientsController::class, 'index']);
# Method (POST) Add Resource
Route::post('/patients', [PatientsController::class, 'tambah']);
# Method (GET) Detail Resource
Route::get('/patients/{id}', [PatientsController::class, 'tampil']);
# Method (PUT) Edit Resource
Route::put('/patients/{id}', [PatientsController::class, 'ubah']);
# Method (DELETE) Delete Resource
Route::delete('/patients/{id}', [PatientsController::class, 'hapus']);
# Method (GET) Search Resource by name
Route::get('/patients/search/{name}', [PatientsController::class, 'search']);
# Method (GET) Positive Resource
Route::get('/patients/status/positive', [PatientsController::class, 'positive']);
# Method (GET) negatif Resource
Route::get('/patients/status/negatif', [PatientsController::class, 'negatif']);
# Method (GET) Recovered Resource
Route::get('/patients/status/recovered', [PatientsController::class, 'recovered']);
# Method (GET) Dead Resource
Route::get('/patients/status/dead', [PatientsController::class, 'dead']);