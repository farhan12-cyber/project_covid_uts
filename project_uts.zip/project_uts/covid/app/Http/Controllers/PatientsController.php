<?php

// Nama : Muhammad Farhan
// Kelas : 3TI05
// Nim : 0110220079

namespace App\Http\Controllers;

use App\Models\Patients;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PatientsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $patients = Patients::all();

        $total = count($patients);

        if ($total) {
            $data = [
                'message' => 'Get All Resource',
                'total' => $total,
                'data' => $patients
            ];

            return response()->json($data, 200);
        } else {
            $data = [
                'message' => 'Data is empty'
            ];

            return response()->json($data, 200);
        }
    }

    /**
     * @return \Illuminate\Http\Response
     */
    public function tambah(Request $request)
    {
        Validator::make($request->all(), [
            'nama' => 'required',
            'phone' => 'required',
            'address' => 'required',
            'status' => 'required',
            'in_date_at' => 'required',
            'out_date_at' => 'required'
        ])->validate();

        $patients = Patients::create([
            'nama' => $request->nama,
            'phone' => $request->phone,
            'address' => $request->address,
            'status' => $request->status,
            'in_date_at' => $request->in_date_at,
            'out_date_at' => $request->out_date_at
        ]);

        $data = [
            'pesan' => 'Resource is added successfully',
            'data' => $patients
        ];

        return response()->json($data, 201);
    }

    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function tampil($id)
    {
        $patients = Patients::find($id);

        if ($patients) {
            $data = [
                'message' => 'Get Detail Resource',
                'data' => $patients
            ];

            return response()->json($data, 200);
        } else {
            $data = [
                'message' => 'Resource not found'
            ];

            return response()->json($data, 404);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function ubah(Request $request, $id)
    {
        $patients = Patients::find($id);

        if ($patients) {
            $patients->update($request->all());
            $data = [
                'message' => 'Resource is update successfully',
                'data' => $patients
            ];
            return response()->json($data, 200);
        } else {
            $data = [
                'message' => 'Resource not found'
            ];

            return response()->json($data, 404);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Patients  $patients
     * @return \Illuminate\Http\Response
     */
    public function hapus($patients)
    {
        $patients = Patients::find($patients);

        if ($patients) {
            $patients->delete();
            $data = [
                'message' => 'Resource is delete successfully'
            ];

            return response()->json($data, 200);
        } else {
            $data = [
                'message' => 'Resource not found'
            ];

            return response()->json($data, 404);
        }
    }

    /**
     * Method (GET) Search Resource by name.
     *
     *
     * @return \Illuminate\Http\Response
     */
    public function search($name)
    {
        $patients = Patients::where('nama', 'like', '%' . $name . '%')->get();

        $total = count($patients);

        if ($total) {
            $data = [
                'message' => 'Get searched resource',
                'total' => $total,
                'data' => $patients
            ];

            return response()->json($data, 200);
        } else {
            $data = [
                'message' => 'Resource not found'
            ];

            return response()->json($data, 404);
        }
    }

    /**
     *
     *
     * @return \Illuminate\Http\Response
     */
    public function searchByStatus($status)
    {
        $patients = Patients::where('status', $status)->get();

        $total = count($patients);

        if ($total) {
            $data = [
                'message' => 'Get status resource',
                'total' => $total,
                'data' => $patients
            ];

            return response()->json($data, 200);
        } else {
            $data = [
                'message' => 'Resource not found'
            ];

            return response()->json($data, 404);
        }
    }

    /**
     * Method (GET) Positive Resource.
     *
     *
     * @return \Illuminate\Http\Response
     */
    public function positive()
    {
        return $this->searchByStatus('positive');
    }

    /**
     * Method (GET) Positive Resource.
     *
     *
     * @return \Illuminate\Http\Response
     */
    public function negatif()
    {
        return $this->searchByStatus('negatif');
    }

    /**
     * Method (GET) Recovered Resource.
     *
     *
     * @return \Illuminate\Http\Response
     */
    public function recovered()
    {
        return $this->searchByStatus('recovered');
    }

    /**
     * Method (GET) Dead Resource.
     *
     *
     * @return \Illuminate\Http\Response
     */
    public function dead()
    {
        return $this->searchByStatus('dead');
    }
}